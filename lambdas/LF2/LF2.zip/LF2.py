import json
import boto3
import random
import requests
from requests_aws4auth import AWS4Auth

queueURL = "https://sqs.us-east-1.amazonaws.com/025726486846/Dining_Conceirge_Queue"
senderEmailId = "shantanu.jain@columbia.edu"

def lambda_handler(event, context):
    """
    Lambda Handler for controlling the pipeline
    """
    cuisine, emailID, phoneNumber, receiptHandle = pollSQS()
    if cuisine == None or emailID == None:
        return None
    print(cuisine)
    print(emailID)
    restaurantIdList = fetchRestaurantFromES(event, cuisine)
    restaurantDetailsSet = fetchRestaurantFromDynamo(restaurantIdList)
    response = sendEmailUsingSES(restaurantDetailsSet, emailID, receiptHandle)
    # response = sendSMStoUser(restaurantDetails, phoneNumber)
    return response

def pollSQS():
    """
    Polls SQS for getting user attributes to fetch a restaurant suggestion.
    """
    sqsClient = boto3.client('sqs')
    response = sqsClient.receive_message(
        QueueUrl=queueURL,
        AttributeNames = ['All'],
        MessageAttributeNames = ['All'],
        MaxNumberOfMessages=1,
        WaitTimeSeconds=20
    )
    # print("SQS Response:", response)
    if "Messages" not in response:
        print("No SQS messages to poll. Retry after 60 seconds...")
        return None, None, None, None
    
    # Deleting the message from SQS after receiving a message.
    receiptHandle = response['Messages'][0]['ReceiptHandle']
    # sqsClient.delete_message(QueueUrl=queueURL, ReceiptHandle=receiptHandle)
    
    cuisine = response['Messages'][0]['MessageAttributes']['Cuisine']['StringValue']
    phoneNumber = response['Messages'][0]['MessageAttributes']['PhoneNumber']['StringValue']
    emailID = response['Messages'][0]['MessageAttributes']['Email']['StringValue']
    return cuisine, emailID, phoneNumber, receiptHandle
    

def fetchRestaurantFromES(event, cuisine):
    """
    Fetches the restaurantID from the cuisine from ES.
    """
    # print(cuisine)
    region = 'us-east-1' # For example, us-west-1
    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
    
    host = 'https://search-restaurant-recommender-oaw2lgfifru4kro7umanwj26au.us-east-1.es.amazonaws.com/' # For example, search-mydomain-id.us-west-1.es.amazonaws.com
    index = 'restaurants'
    url = host + index + '/_search'
    query = {
        "size": 25,
        "query": {
            "match": {"cuisine": "Indian"}
        }
    }
    headers = { "Content-Type": "application/json" }
    r = requests.get(url, auth=awsauth, headers=headers, data=json.dumps(query))
    response = {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": '*'
        },
        "isBase64Encoded": False
    }
    response['body'] = r.text
    response['body'] = json.loads(response['body'])
    
    # Take a random restaurant based on cuisine and return its id
    matches = response['body']['hits']['hits']
    # restaurantIdList = random.choices(matches, k=3)
    restaurantIdList = [restaurant['_id'] for restaurant in random.choices(matches, k=3)]
    print(restaurantIdList)
    return restaurantIdList 
    
def fetchRestaurantFromDynamo(restaurantIdList):
    """
    Fetches all the restaurant details by restaurantID from dynamo DB.
    """
    dynamoClient = boto3.client('dynamodb')
    restaurantList = []
    for restaurantId in restaurantIdList:
        response = dynamoClient.get_item(
            TableName="yelp-restaurants",
            Key={
                "id": {
                    "S": restaurantId
                }
            }
        )
        restaurantList.append(response['Item'])
    return restaurantList
    
def sendSMStoUser(restaurant, phoneNumber):
    """
    Sends SMS to User. Not used because SMS limit reached.
    """
    
    snsClient = boto3.client('sns')
    restaurantName = restaurant['name']['S']
    restaurantAddress = ""
    for address in restaurant['location']['M']['display_address']['L']:
        restaurantAddress += address['S']
        restaurantAddress += ", "
    reviewCount = restaurant['review_count']['N']
    cuisine = restaurant['cuisine']['S']
    ratings = restaurant['rating']['N']
    smsMessage = """Hi! Please find the below restaurant as per your preferences, 
    - RestaurantName: {},
    - RestaurantAddress: {},
    - Ratings: {},
    - Reviews: {},
    - Cuisine: {}
    """.format(restaurantName, restaurantAddress, ratings, reviewCount, cuisine)
    print("Sending an SMS to the user.")
    response = snsClient.publish(
        PhoneNumber=phoneNumber,
        Message=smsMessage,
        MessageAttributes={
            "AWS.SNS.SMS.SMSType": {
                "DataType": "String",
                "StringValue": "Transactional"
            }
        }
        )
    return response
    
# def sendEmailToUser(restaurant, emailID, receiptHandle):
#     snsTopicArn = "arn:aws:sns:us-east-1:996208533033:SendRestaurantDetailsToUser"
#     snsClient = boto3.client('sns')
#     sqsClient = boto3.client('sqs')
    
#     restaurantName = restaurant['name']['S']
#     restaurantAddress = ""
#     for address in restaurant['location']['M']['display_address']['L']:
#         restaurantAddress += address['S']
#     reviewCount = restaurant['review_count']['N']
#     ratings = restaurant['rating']['N']
#     cuisine = restaurant['cuisine']['S']
#     smsMessage = """Hi! Please find the below restaurant as per your preferences, 
#     - RestaurantName: {},
#     - RestaurantAddress: {},
#     - Ratings: {},
#     - Reviews: {},
#     - Cuisine: {}
#     """.format(restaurantName, restaurantAddress, ratings, reviewCount, cuisine)

#     snsSubscriptionResponse = snsClient.list_subscriptions_by_topic(TopicArn=snsTopicArn)
#     subscriptions = snsSubscriptionResponse['Subscriptions']
#     for subscription in subscriptions:
#         # Email id is already subscribed
#         if emailID == subscription['Endpoint']:
#             print("User is already subscribed.")
#             emailResponse = snsClient.publish(
#                 TopicArn=snsTopicArn,
#                 Message=smsMessage,
#                 Subject="Dining Conceirge Chatbot!"
#             )
            
#             # Delete the message from the SQS queue.
#             print("deleting the sqs message...")
#             sqsClient.delete_message(QueueUrl=queueURL, ReceiptHandle=receiptHandle)
#             return emailResponse
    
#     # if the user is not subscribed, then make a confirmation mail
#     print("subscribing the user...")
#     response = snsClient.subscribe(
#         TopicArn=snsTopicArn,
#         Protocol="email",
#         Endpoint=emailID,
#         ReturnSubscriptionArn=True
#     )
#     print(response)
#     return response
    
def sendEmailUsingSES(restaurantDetailsSet, emailID, receiptHandle):
    """
    Sends emails to the user by first verifying their address and sending them the restaurant suggestions.
    This is done using SES.
    """
    
    sesClient = boto3.client('ses')
    sqsClient = boto3.client('sqs')
    # check whether the user has been verified or not
    verifiedResponse = sesClient.list_verified_email_addresses()
    if emailID not in verifiedResponse['VerifiedEmailAddresses']:
        # verify email and return
        verifyEmailResponse = sesClient.verify_email_identity(EmailAddress=emailID)
        return
    
    message = "Hi, Here is the list of restaurants that I found out that mights suit you:\n"
    message_restaurant = ""
    count = 1
    for restaurant in restaurantDetailsSet:
        restaurantName = restaurant['name']['S']
        restaurantAddress = ""
        for address in restaurant['location']['M']['display_address']['L']:
            restaurantAddress += address['S']
            restaurantAddress += ", "
        reviewCount = restaurant['review_count']['N']
        ratings = restaurant['rating']['N']
        cuisine = restaurant['cuisine']['S']
        message_restaurant += str(count)+" RestaurantName: {}, Address: {}, Ratings: {}, Reviews: {}, Cuisine: {} \n".format(restaurantName, restaurantAddress, ratings, reviewCount, cuisine)
        count += 1
        # smsMessage = """Hi! Please find the below restaurant as per your preferences, \n
        # - RestaurantName: {}\n,
        # - RestaurantAddress: {}\n,
        # - Ratings: {}\n,
        # - Reviews: {}\n,
        # - Cuisine: {}\n
        # """.format(restaurantName+"\n", restaurantAddress+"\n", ratings+"\n", reviewCount+"\n", cuisine+"\n")    

    # Send a mail to the user regarding the restaurant suggestions
    mailResponse = sesClient.send_email(
        Source=senderEmailId,
        Destination={'ToAddresses': [emailID]},
        Message={
            'Subject': {
                'Data': "Dining Conceirge Chatbot has a message for you!",
                'Charset': 'UTF-8'
            },
            'Body': {
                'Text': {
                    'Data': message+message_restaurant,
                    'Charset': 'UTF-8'
                },
                'Html': {
                    'Data': message+message_restaurant,
                    'Charset': 'UTF-8'
                }
            }
        }
    )

    # Deleting the SQS queue message
    print("deleting the sqs message...")
    sqsClient.delete_message(QueueUrl=queueURL, ReceiptHandle=receiptHandle)
    return mailResponse